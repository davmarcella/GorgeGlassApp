package com.example.david.mapapp;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.io.File;
import java.io.IOException;
import java.net.URI;

/**
 * Created by David on 12/5/16.
 */

public class PostActivity extends Activity{

    private DBase db;
    private ImageView img1;
    private ImageView img2;
    private TextView itemName;
    private TextView clues;
    private TextView loc;
    private LostItem item;
    private TextView found;
    private Button foundBtn;


    protected void onCreate(Bundle savedInstanceBundle){
        super.onCreate(savedInstanceBundle);
        setContentView(R.layout.post_layout);

        //initialize variables
        img1 = (ImageView) findViewById(R.id.uploadImage1);
        img2 = (ImageView) findViewById(R.id.uploadImage2);
        found = (TextView) findViewById(R.id.foundText);
        foundBtn = (Button) findViewById(R.id.foundButton);

        db = new DBase(this);
        itemName = (TextView) findViewById(R.id.itemNameTV);
        clues = (TextView) findViewById(R.id.cluesTV);
        loc = (TextView) findViewById(R.id.LatLongTV);
        RelativeLayout layout = (RelativeLayout) findViewById(R.id.post_layout);
        SharedPreferences myPref = getApplicationContext().getSharedPreferences("MyPreferences", MODE_PRIVATE);


        //set the background color based on preferences
        String bckgrndColor = myPref.getString("color", null);
        switch(bckgrndColor){
            case "b":
                layout.setBackgroundColor(getResources().getColor(R.color.blue));
                break;
            case "p":
                layout.setBackgroundColor(getResources().getColor(R.color.purple));
                break;
            case "g":
                layout.setBackgroundColor(getResources().getColor(R.color.green));
                break;
            case "o":
                layout.setBackgroundColor(getResources().getColor(R.color.orange));
                break;
            case "y":
                layout.setBackgroundColor(getResources().getColor(R.color.yellow));
                break;
            case "r":
                layout.setBackgroundColor(getResources().getColor(R.color.red));
                break;
            case "pi":
                layout.setBackgroundColor(getResources().getColor(R.color.pink));
                break;
            default:
                break;
        }

        //get the intent and associated variables
        Intent intent = getIntent();
        int id = intent.getIntExtra("itemID", -1);
        item = db.getLostItem(id);

        //sets the "Found!" image on top of the activity to invisible unless its been found
        LostItem l = item;
        if(item.found() == 1){
            found.setVisibility(View.VISIBLE);
            foundBtn.setVisibility(View.INVISIBLE);
            l.setFound(1);
            db.editLostItem(l);
        }


        //set the imageViews
        if(!item.getImgText1().equals("")) {
            int imgID1 = getResources().getIdentifier(item.getImgText1(), "drawable", getPackageName());
            int imgID2  = getResources().getIdentifier(item.getImgText2(), "drawable", getPackageName());
            img1.setImageResource(imgID1);
            img2.setImageResource(imgID2);

        }

        //set the text views
        itemName.setText(item.getItem());
        clues.setText(item.getClues());
        loc.setText(item.getLat() + ", " + item.getLong());
    }

    //function called when found button is clicked
    public void found(View v){
        LostItem l = item;
        if(l.found() == 1){
            //do nothing
        }
        //if it's not already found display the found text
        else {
            found.setVisibility(v.VISIBLE);
            l.setFound(1);
            db.editLostItem(l);

        }
    }

    //finish when you click done
    public void doneViewPost(View v){
        finish();
    }

    //when the first image is clicked
    public void imageClick1(View v){
        Intent intent = new Intent(this, ShowImageActivity.class);
        intent.putExtra("img", item.getImgText1());
        startActivity(intent);
    }

    //when the second image is clicked
    public void imageClick2(View v){
        Intent intent = new Intent(this, ShowImageActivity.class);
        intent.putExtra("img", item.getImgText2());
        startActivity(intent);
    }




}
