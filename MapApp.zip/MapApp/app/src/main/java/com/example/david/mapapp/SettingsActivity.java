package com.example.david.mapapp;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.RadioGroup.OnCheckedChangeListener;


/**
 * Created by David on 11/29/16.
 */

public class SettingsActivity extends Activity {

    private SharedPreferences myPref;
    private RadioGroup colors;
    private RelativeLayout layout;
    private SharedPreferences.Editor ed;
    private String bckgrndColor;
    private EditText name;
    private EditText email;
    private String nametxt;
    private String emailtxt;
    private CheckBox glassB;



    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings_layout);

        //initialize variables
        myPref = getApplicationContext().getSharedPreferences("MyPreferences", MODE_PRIVATE);
        colors = (RadioGroup) findViewById(R.id.ColorRG);
        layout = (RelativeLayout) findViewById(R.id.settings_layout);
        name = (EditText) findViewById(R.id.nameET);
        email = (EditText) findViewById(R.id.emailET);
        glassB = (CheckBox) findViewById(R.id.glassBlower);
        ed = myPref.edit();


        //set background colors
        bckgrndColor = myPref.getString("color", null);
        switch(bckgrndColor){
            case "b":
                layout.setBackgroundColor(getResources().getColor(R.color.blue));
                break;
            case "p":
                layout.setBackgroundColor(getResources().getColor(R.color.purple));
                break;
            case "g":
                layout.setBackgroundColor(getResources().getColor(R.color.green));
                break;
            case "o":
                layout.setBackgroundColor(getResources().getColor(R.color.orange));
                break;
            case "y":
                layout.setBackgroundColor(getResources().getColor(R.color.yellow));
                break;
            case "r":
                layout.setBackgroundColor(getResources().getColor(R.color.red));
                break;
            case "pi":
                layout.setBackgroundColor(getResources().getColor(R.color.pink));
                break;
            default:
                break;
        }


        //set listener for radioGroup
        colors.setOnCheckedChangeListener(colorListener);
        name.addTextChangedListener(nameListener);
        email.addTextChangedListener(emailListener);
        glassB.setOnClickListener(glassListener);
    }

    private TextWatcher nameListener = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {}
        @Override
        public void afterTextChanged(Editable s) {
            nametxt = s.toString();
            ed.putString("name", nametxt);

        }
    };

    private TextWatcher emailListener = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {}
        @Override
        public void afterTextChanged(Editable s) {
            emailtxt = s.toString();
            ed.putString("email", emailtxt);

        }
    };

    private View.OnClickListener glassListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if(((CheckBox) v).isChecked())
                ed.putBoolean("glassblower", true);
            else
                ed.putBoolean("glassblower", false);
        }
    };

    //changes the background color and the color preference in preferences
    private OnCheckedChangeListener colorListener = new OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(RadioGroup group, int checkedId) {
            switch(checkedId){
                case R.id.blueCheckBox:
                    layout.setBackgroundColor(getResources().getColor(R.color.blue));
                    bckgrndColor = "b";
                    ed.putString("color", bckgrndColor);
                    break;
                case R.id.purpleCheckBox:
                    layout.setBackgroundColor(getResources().getColor(R.color.purple));
                    bckgrndColor = "p";
                    ed.putString("color", bckgrndColor);
                    break;
                case R.id.greenCheckBox:
                    layout.setBackgroundColor(getResources().getColor(R.color.green));
                    bckgrndColor = "g";
                    ed.putString("color", bckgrndColor);
                    break;
                case R.id.yellowCheckBox:
                    layout.setBackgroundColor(getResources().getColor(R.color.yellow));
                    bckgrndColor = "y";
                    ed.putString("color", bckgrndColor);
                    break;
                case R.id.orangeCheckBox:
                    layout.setBackgroundColor(getResources().getColor(R.color.orange));
                    bckgrndColor = "o";
                    ed.putString("color", bckgrndColor);
                    break;
                case R.id.pinkCheckBox:
                    layout.setBackgroundColor(getResources().getColor(R.color.pink));
                    bckgrndColor = "pi";
                    ed.putString("color", bckgrndColor);
                    break;
                case R.id.redCheckBox:
                    layout.setBackgroundColor(getResources().getColor(R.color.red));
                    bckgrndColor = "r";
                    ed.putString("color", bckgrndColor);
                    break;
            }
            ed.commit();
        }
    };

    //when done button is clicked
    public void doneSettings(View v){
        finish();
    }
}
