package com.example.david.mapapp;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

/**
 * Created by David on 12/8/16.
 */

public class RulesActivity extends Activity {

    private RelativeLayout layout;
    private SharedPreferences myPref;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.rules_layout);

        layout = (RelativeLayout) findViewById(R.id.rules_layout);

        //get background color stuff from preferences
        myPref = getApplicationContext().getSharedPreferences("MyPreferences", MODE_PRIVATE);
        String bckgrndColor = myPref.getString("color", null);

        //change the color based on the preferences
        switch(bckgrndColor){
            case "b":
                layout.setBackgroundColor(getResources().getColor(R.color.blue));
                break;
            case "p":
                layout.setBackgroundColor(getResources().getColor(R.color.purple));
                break;
            case "g":
                layout.setBackgroundColor(getResources().getColor(R.color.green));
                break;
            case "o":
                layout.setBackgroundColor(getResources().getColor(R.color.orange));
                break;
            case "y":
                layout.setBackgroundColor(getResources().getColor(R.color.yellow));
                break;
            case "r":
                layout.setBackgroundColor(getResources().getColor(R.color.red));
                break;
            case "pi":
                layout.setBackgroundColor(getResources().getColor(R.color.pink));
                break;
            default:
                break;
        }
    }

    public void doneRules(View v){finish();}
}
