package com.example.david.mapapp;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.gms.maps.SupportMapFragment;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.net.URI;

/**
 * Created by David on 11/29/16.
 */

public class NewPostActivity extends Activity {

    private ImageView img1;
    private ImageView img2;
    private static final int RESULT_LOAD_IMAGE = 1;
    private TextView name;
    private TextView clues;
    private String img1Str;
    private String img2Str;
    private String lat;
    private String log;
    private DBase db;
    private SharedPreferences myPref;
    private String bckgrndColor;
    private RelativeLayout layout;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.new_post_layout);

        //initialize intent variables
        Intent intent = getIntent();
        lat = intent.getStringExtra("Latitude");
        log = intent.getStringExtra("Longitude");

        //initialize variables
        layout = (RelativeLayout) findViewById(R.id.new_post_layout);
        img1 = (ImageView) findViewById(R.id.uploadImage1);
        img2 = (ImageView) findViewById(R.id.uploadImage2);
        name = (TextView) findViewById(R.id.itemText);
        clues = (TextView) findViewById(R.id.cluesText);
        myPref = getApplicationContext().getSharedPreferences("MyPreferences", MODE_PRIVATE);
        bckgrndColor = myPref.getString("color", null);
        img1Str = "";
        img2Str = "";
        db = new DBase(this);

        //change the color based on the preferences
        switch(bckgrndColor){
            case "b":
                layout.setBackgroundColor(getResources().getColor(R.color.blue));
                break;
            case "p":
                layout.setBackgroundColor(getResources().getColor(R.color.purple));
                break;
            case "g":
                layout.setBackgroundColor(getResources().getColor(R.color.green));
                break;
            case "o":
                layout.setBackgroundColor(getResources().getColor(R.color.orange));
                break;
            case "y":
                layout.setBackgroundColor(getResources().getColor(R.color.yellow));
                break;
            case "r":
                layout.setBackgroundColor(getResources().getColor(R.color.red));
                break;
            case "pi":
                layout.setBackgroundColor(getResources().getColor(R.color.pink));
                break;
            default:
                break;
        }




    }


    //selects photo and saves it to appropriate image view and string variables
    public void selectPhoto(View v){
        Intent galleryIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(galleryIntent, RESULT_LOAD_IMAGE);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK && data != null){
            Uri selectedImage = data.getData();
            if(img1.getDrawable() == null){
                img1.setImageURI(selectedImage);
                //here you would set the img1Str to something to put it in the dB
            }
            else {
                img2.setImageURI(selectedImage);
                //here you would set the img2Str to something to put it in the dB
            }


        }
    }

    //takes everything entered by user and creates a LostItem variable and adds it to the
    public void done(View v){
        //pull up database and put everything inside database.
        LostItem l = new LostItem(db.getAllLostItems().size()+1, name.getText().toString(), clues.getText().toString(), lat, log, 0, img1Str, img2Str);
        db.addLostItem(l);
        finish();
    }

    //cancel button
    public void cancel(View v){
        finish();
    }

}
