package com.example.david.mapapp;

/**
 * Created by David on 11/29/16.
 */

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;

class DBase extends SQLiteOpenHelper {

    //TASK 1: DEFINE THE DATABASE AND TABLE
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "GlassHunters";
    private static final String DATABASE_TABLE = "ItemsLost";


    //TASK 2: DEFINE THE COLUMN NAMES FOR THE TABLE
    private static final String id = "id";
    private static final String lostItem = "itemLost";
    private static final String clues = "clues";
    private static final String latitude = "latitude";
    private static final String longitude = "longitude";
    private static final String found = "found";
    private static final String imgUriStr1 = "imageText1";
    private static final String imgUriStr2 = "imageText2";


    public DBase (Context context){
        super (context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate (SQLiteDatabase database){
        System.out.println("here2");
        String table = "CREATE TABLE " + DATABASE_TABLE + "("
            + id + " INTEGER, "
            + lostItem + " TEXT, "
            + clues + " TEXT, "
            + latitude + " TEXT, "
            + longitude + " TEXT, "
            + found + " INTEGER, "
            + imgUriStr1 + " TEXT, "
            + imgUriStr2 + " TEXT" + ")";
        database.execSQL (table);
    }

    @Override
    public void onUpgrade(SQLiteDatabase database,
                          int oldVersion,
                          int newVersion) {
        System.out.println("here3");
        database.execSQL("DROP TABLE IF EXISTS " + DATABASE_TABLE);
        onCreate(database);
    }

    //********** DATABASE OPERATIONS:  ADD, EDIT, DELETE


    public void addLostItem(LostItem l) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(id, l.getId());

        values.put(lostItem, l.getItem());

        values.put(clues, l.getClues()); // task name

        values.put(latitude, l.getLat());

        values.put(longitude, l.getLong());

        values.put(found, l.found());

        values.put(imgUriStr1, l.getImgText1());

        values.put(imgUriStr2, l.getImgText2());

        // INSERT THE ROW IN THE TABLE
        db.insert(DATABASE_TABLE, null, values);

        // CLOSE THE DATABASE CONNECTION
        db.close();
    }

    public void editLostItem(LostItem l){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(id, l.getId());

        values.put(lostItem, l.getItem());

        values.put(clues, l.getClues());

        values.put(latitude, l.getLat());

        values.put(longitude, l.getLong());

        values.put(found, l.found());

        values.put(imgUriStr1, l.getImgText1());

        values.put(imgUriStr2, l.getImgText2());

        db.update(DATABASE_TABLE, values, id + " = ?",
                new String[]{
                        String.valueOf(l.getId())
                });
        db.close();
    }

    public LostItem getLostItem(int nId){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(
                DATABASE_TABLE,
                new String[]{id, lostItem, clues, latitude, longitude, found, imgUriStr1, imgUriStr2},
                id + "=?",
                new String[]{String.valueOf(nId)},
                null, null, null, null );

        if (cursor != null)
            cursor.moveToFirst();

        LostItem l = new LostItem(
                cursor.getInt(0),
                cursor.getString(1),
                cursor.getString(2),
                cursor.getString(3),
                cursor.getString(4),
                cursor.getInt(5),
                cursor.getString(6),
                cursor.getString(7));
        db.close();
        return l;
    }

    public void deleteLostItem (LostItem l){
        SQLiteDatabase database = this.getReadableDatabase();

        // DELETE THE TABLE ROW
        database.delete(DATABASE_TABLE, id + " = ?",
                new String[]
                        {String.valueOf(l.getId())});

        database.close();
    }

    public void deleteAllItems(){
        this.getReadableDatabase().execSQL("DELETE FROM " + DATABASE_TABLE);
    }

    public ArrayList<LostItem> getAllLostItems() {
        ArrayList<LostItem> lostItems= new ArrayList<LostItem>();
        String queryList = "SELECT * FROM " + DATABASE_TABLE;

        SQLiteDatabase database = this.getReadableDatabase();
        Cursor cursor = database.rawQuery(queryList, null);

        //COLLECT EACH ROW IN THE TABLE
       if (cursor.moveToFirst() && cursor.getCount() != 0){
            do {
                LostItem l = new LostItem();
                l.setId(cursor.getInt(0));
                l.setItem(cursor.getString(1));
                l.setClues(cursor.getString(2));
                l.setLat(cursor.getString(3));
                l.setLong(cursor.getString(4));
                l.setFound(cursor.getInt(5));
                l.setImgText1(cursor.getString(6));
                l.setImgText2(cursor.getString(7));

                //ADD TO THE QUERY LIST
                lostItems.add(l);
            } while (cursor.moveToNext());
        }
        return lostItems;
    }
}