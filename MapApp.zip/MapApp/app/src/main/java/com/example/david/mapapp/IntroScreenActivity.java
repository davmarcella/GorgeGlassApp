package com.example.david.mapapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by David on 12/8/16.
 */

public class IntroScreenActivity extends Activity {

    private Intent intent;

    protected void onCreate(Bundle savedInstanceBundle){
        super.onCreate(savedInstanceBundle);
        setContentView(R.layout.intro_screen);

        //wait time of 5 seconds
        long waitTime = 4000;
        //call activity to start app
        intent = new Intent(this, MapsActivity.class);


        //wait and then start the activity
        Timer timer = new Timer();
        timer.schedule(new TimerTask(){
            public void run(){
                startActivity(intent);
            }
        }, waitTime);

    }
}
