package com.example.david.mapapp;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.location.Location;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.location.LocationServices;

import java.util.ArrayList;

public class MapsActivity extends FragmentActivity implements GoogleMap.OnMyLocationButtonClickListener,
        OnMapReadyCallback, GoogleMap.OnMapClickListener,
        ActivityCompat.OnRequestPermissionsResultCallback,
        GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, GoogleMap.OnMarkerClickListener {

    /**
     * Request code for location permission request.
     *
     * @see #onRequestPermissionsResult(int, String[], int[])
     */
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1;

    /**
     * Flag indicating whether a requested permission has been denied after returning in
     * {@link #onRequestPermissionsResult(int, String[], int[])}.
     */
    private boolean mPermissionDenied = false;
    private GoogleMap mMap;
    private GoogleApiClient mGoogleApiClient;
    private Location mLastLocation;
    private String mLatitudeText;
    private String mLongitudeText;
    private SharedPreferences myPref;
    private DBase db;
    private ArrayList<LostItem> items;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        // Create an instance of GoogleAPIClient.
        // This is necessary to connect to Google services such as maps
        if (mGoogleApiClient == null) {
            mGoogleApiClient = new GoogleApiClient.Builder(this)
                    .addConnectionCallbacks(this)
                    .addOnConnectionFailedListener(this)
                    .addApi(LocationServices.API)
                    .build();
        }


        //initialize database
        db = new DBase(this);


        //UNCOMMENT IF STARTING OVER WITH ONLY INITIAL 5 LOCATIONS
//        db.deleteAllItems();
//
//        LostItem lostI = new LostItem(db.getAllLostItems().size()+1, "Miles Parker Marble", "1) It’s near the car\n2) You don’t need to move any rocks\n3) It’s in the picture\n4) Surrounded by wood", "42.452856" , "-76.359467", 0, "marble1", "marble1_spot");
//        db.addLostItem(lostI);
//        lostI = new LostItem(db.getAllLostItems().size()+1, "Aaron verity marble 2014" , "1) it lies in water but no need to swim\n2) No need to worry about it floating away\n3) It lays in a pool which does not move\n4) You may need to get your elbows dirty", "42.433891", "-76.485073", 0, "marble2", "marble2_spot");
//        db.addLostItem(lostI);
//        lostI = new LostItem(db.getAllLostItems().size()+1, "Set of soft-glass glasses", "1. Neither are in the pictures\n2. You may need boots to get to one\n3. Hidden during the dry season so be careful if the water level rises", "42.418917", "-76.462807", 1, "glasses", "glasses_spot");
//        db.addLostItem(lostI);
//        lostI = new LostItem(db.getAllLostItems().size()+1, "Colorful unknown marble", "1) It’s not in any store\n2) No random person should be able to find it\n3) Make sure you check every crack and crevice\n4) Will be back weekly to check on status of marble", "42.452523", "-76.491555", 0, "marble3", "marble3_spot");
//        db.addLostItem(lostI);
//        lostI = new LostItem(db.getAllLostItems().size()+1, "Children Friendly Noah Drew Marble Hunt" ,"1) All marbles are in/near Taughannock Falls State Park\n2) No climbing or walking past barriers necessary\n3) Some marbles may be wet but none sit in/near the water\n4) All marbles are under 1 inch in diameter\n4) No marbles are on the upper trail\n5) Stay safe and enjoy the hunt!", "42.544845", "-76.600890", 0, "marble4", "marble4_spot");
//        db.addLostItem(lostI);
//        lostI = new LostItem(db.getAllLostItems().size()+1, "East Hill Hunt CHILDREN ONLY!", "MUST BE A CHILD TO PARTICIPATE\n\n- 10 marbles total are lost\n- All along the Vincent and Hannah Pew Trail\n- no going into yards\n-Trees and rocks are good places to check\n- 3 in the front, 4 in the middle, 2 in the back\n- Big marble in a unique and more challenging location\n Have fun :)", "42.429826", "-76.462099",0, "marbles1", "marbles1Spot");
//        db.addLostItem(lostI);
//        lostI = new LostItem(db.getAllLostItems().size()+1, "Lost pendant", "No need to swim\nNo need to climb\nNo need to get dirty or wet\nIt's in the picture\nIt definitely won't wash away and it shouldn't get wet", "42.434138", "-76.485051", 1, "pendant1", "pendant1Spot");
//        db.addLostItem(lostI);
//        lostI = new LostItem(db.getAllLostItems().size()+1, "Out Of State!\nLost Marble at Red Rocks Amphitheater", "1 Not located exactly where the lat/long is\nI just was there when I posted\n2 Tucked away tight in the picture\n3 if not grabbed soon, could be grabbed by some VIP action", "39.665351", "-105.206220", 0, "marble5", "marble5Spot");
//        db.addLostItem(lostI);
//        lostI = new LostItem(db.getAllLostItems().size()+1, "Unknown artist marble lost" ,"No swimming required and located in Danby\nLocation is at my house so this should be more difficult!","42.444479", "-76.499408", 0, "marble6","marble6Spot");
//        db.addLostItem(lostI);
//        lostI = new LostItem(db.getAllLostItems().size()+1, "UV Keith Allen Marble", "\"I left the woods for as good a reason as I went there. Perhaps it seemed to me that I had several more lives to live, and could not spare anymore time for that one. It is remarkable how easily and insensibly we fall into a particular route, and make a beaten path for ourselves.\"\nI believe we all have freedom to choose our own paths. For my first ever hide I chose a place that means quite a lot to me. And there are multiple ways to get to your destination, so choose away. There is also a bonus hide to help you enjoy this Keith Allen marble to its fullest.","42.425054", "-76.508259", 1, "marble7","marble7Spot");
//        db.addLostItem(lostI);
//        lostI = new LostItem(db.getAllLostItems().size()+1, "Marble I(Miles Parker) made during filming", "No climbing needed!\nNot in the picture but in the general area\nVery Hard!! Good luck!", "42.452486", "-76.491590", 0, "marble8", "marble8Spot");
//        db.addLostItem(lostI);
//        lostI = new LostItem(db.getAllLostItems().size()+1, "Noah Drew 2016 Marble","No clues today fellas. Only the pictures and location.","42.457590", "-76.515184", 0, "marble9", "marble9Spot");
//        db.addLostItem(lostI);
//        lostI = new LostItem(db.getAllLostItems().size()+1, "Mystery Duck", "Hid a special little something inside of this duck\nReleased it with my wife and daughter today at this wonderful spot\nLocation obviously won't give you any clues as to where along the water the duck may be\nGood luck everyone and happy hunting!","42.401944", "-76.585702", 0, "mysteryduck", "mysteryduckSpot");
//        db.addLostItem(lostI);
//        lostI = new LostItem(db.getAllLostItems().size()+1, "Private Hide for Dominic", "Passing the hot potato after its detour at Doston Park\nIt's not in plain sight, the number 37 once again rears it's head\nOh... and don't get shot by an arrow (nor hit by a ball, which is much more likely)", "42.416613", "-76.524325", 1, "marble10", "marble10Spot");
//        db.addLostItem(lostI);


        items = db.getAllLostItems();

        //create preferences
        SharedPreferences myPref = getApplicationContext().getSharedPreferences("MyPreferences", MODE_PRIVATE);
        SharedPreferences.Editor ed = myPref.edit();
        ed.putString("color", "");
        ed.commit();


    }

    //starts the new post activity when the button is clicked
    public void newPost(View v){
        Intent intent = new Intent (this, NewPostActivity.class);
        intent.putExtra("Latitude", mMap.getMyLocation().getLatitude()+"");
        intent.putExtra("Longitude", mMap.getMyLocation().getLongitude()+"");
        startActivity(intent);
    }

    //starts the settings activity when the button is clicked
    public void settings(View v){
        Intent intent = new Intent(this, SettingsActivity.class);
        startActivity(intent);
    }

    //starts the rules activity when the button is clicked
    public void rules(View v){
        Intent intent = new Intent(this, RulesActivity.class);
        startActivity(intent);
    }

    /**
     * Use the lifecycle methods to connect/disconnect to google services.
     * Necessary for using maps
     */
    protected void onStart() {
        mGoogleApiClient.connect();
        super.onStart();

        //is this where i would do the switch for colors in settings?
    }

    protected void onStop() {
        mGoogleApiClient.disconnect();
        super.onStop();
    }


    @Override
    protected void onResumeFragments() {
        super.onResumeFragments();
        if (mPermissionDenied) {
            // Permission was not granted, display error dialog.
            //showMissingPermissionError();
            Log.v("onResumeFragments", "Permission was denied");
            mPermissionDenied = false;
        }


    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera
        // LatLng sydney = new LatLng(-34, 151);
        // mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
        // mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));

        mMap.setOnMyLocationButtonClickListener(this);
        mMap.setOnMapClickListener(this);
        mMap.setOnMarkerClickListener(this);

        LatLng position;
        LostItem lItem;
        MarkerOptions m;

        //lay down the markers for the map in the according colors
        for(int i = 0; i < items.size(); i++){
            lItem = items.get(i);
            position = new LatLng(Double.parseDouble(lItem.getLat()), Double.parseDouble(lItem.getLong()));
            //if it's a children's hide
            if(lItem.getItem().toLowerCase().contains("children") && lItem.found() == 0)
                m = new MarkerOptions().position(position).title(lItem.getItem()).snippet(lItem.getId()+"").icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_MAGENTA));
                //if it's a private hide
            else if(lItem.getItem().toLowerCase().contains("private") && lItem.found() == 0)
                m = new MarkerOptions().position(position).title(lItem.getItem()).snippet(lItem.getId()+"").icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_CYAN));
                //if it's a normal hide
            else if(lItem.found()==0)
                m = new MarkerOptions().position(position).title(lItem.getItem()).snippet(lItem.getId()+"").icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE));
                //if it's been found
            else
                m = new MarkerOptions().position(position).title(lItem.getItem()).snippet(lItem.getId()+"");
            mMap.addMarker(m);
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(position, 8));
        }

        enableMyLocation();
    }

    @Override
    public boolean onMarkerClick(Marker marker){
        LostItem l = db.getLostItem(Integer.parseInt(marker.getSnippet()));
        Intent intent = new Intent(MapsActivity.this, PostActivity.class);
        intent.putExtra("itemID", l.getId());
        startActivity(intent);
        return false;
    }

    /**
     * This is the callback method for the mapClickListener
     * @param point the place on the map that was clicked.  Contains latitude and longitude
     */
    @Override
    public void onMapClick(LatLng point) {
        //Toast.makeText(this, "Map clicked", Toast.LENGTH_SHORT).show();
        Log.v("DEBUG", "Map clicked [" + point.latitude + " / " + point.longitude + "]");

    }

    /**
     * Enables the My Location layer if the fine location permission has been granted.
     */
    private void enableMyLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            // Permission to access the location is missing.
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_REQUEST_CODE
            );
            /*
            ActivityCompat.requestPermissions(thisActivity,
                    new String[]{Manifest.permission.READ_CONTACTS},
                    MY_PERMISSIONS_REQUEST_READ_CONTACTS);
            */
        } else if (mMap != null) {
            // Access to the location has been granted to the app.
            mMap.setMyLocationEnabled(true);
            Log.v("enableMyLocation: ", "Permission granted");
        }
    }

    @Override
    public boolean onMyLocationButtonClick() {
        // Return false so that we don't consume the event and the default behavior still occurs
        // (the camera animates to the user's current position).
        Log.v("MapsActivity:", "Map click detected");
        // Add a marker in Sydney and move the camera
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return false;
        }
        Location mLastLocation = LocationServices.FusedLocationApi.getLastLocation(
                mGoogleApiClient);

        LatLng myLoc = new LatLng(mLastLocation.getLatitude(), mLastLocation.getLongitude());
        Toast.makeText(this, "Hit the create new post button!", Toast.LENGTH_SHORT).show();
        mMap.moveCamera(CameraUpdateFactory.newLatLng(myLoc));

        //saves the lat and long temporarily somewhere
        return false;
    }




    /**
     * These next three methods are part of the interface that must be implemented to
     * connect to google services.  We're basically connecting to google to use their API
     * including maps
     * @param connectionHint
     */
    @Override
    public void onConnected(Bundle connectionHint) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        mLastLocation = LocationServices.FusedLocationApi.getLastLocation(
                mGoogleApiClient);
        if (mLastLocation != null) {
            mLatitudeText = String.valueOf(mLastLocation.getLatitude());
            mLongitudeText = String.valueOf(mLastLocation.getLongitude());
        }
    }

    @Override
    public void onConnectionSuspended(int result) {
        Log.v("Connection Suspended: ", " " + result);
    }

    @Override
    public void onConnectionFailed(ConnectionResult result) {
        Log.v("Connection Failed ", result.getErrorMessage());
    }

    /**
     *  These next methods are used to obtain permissions for using maps
     *
     **/
    @Override
    //public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
    //                                       @NonNull int[] grantResults) {
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        if (requestCode != LOCATION_PERMISSION_REQUEST_CODE) {
            return;
        }

        if (isPermissionGranted(permissions, grantResults,
                Manifest.permission.ACCESS_FINE_LOCATION)) {
            // Enable the my location layer if the permission has been granted.
            enableMyLocation();
            Log.v("onRequestPermRslt:  ", "enabled permissions");
        } else {
            // Display the missing permission error dialog when the fragments resume.
            mPermissionDenied = true;
            Log.v("onRequestPermRslt:  ", "DISABLED permissions");
        }
    }

    /**
     * Checks if the result contains a {@link PackageManager#PERMISSION_GRANTED} result for a
     * permission from a runtime permissions request.
     *
     * @see android.support.v4.app.ActivityCompat.OnRequestPermissionsResultCallback
     */
    public static boolean isPermissionGranted(String[] grantPermissions, int[] grantResults,
                                              String permission) {
        for (int i = 0; i < grantPermissions.length; i++) {
            if (permission.equals(grantPermissions[i])) {
                return grantResults[i] == PackageManager.PERMISSION_GRANTED;
            }
        }
        return false;
    }



}