package com.example.david.mapapp;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;

/**
 * Created by David on 12/8/16.
 */

public class ShowImageActivity extends Activity {

    private ImageView img;
    private Button done;
    private RelativeLayout layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.show_image_layout);

        Intent intent = getIntent();
        String imgSrc = intent.getStringExtra("img");

        img = (ImageView) findViewById(R.id.enlargedImage);
        done = (Button) findViewById(R.id.doneShowImageButton);
        layout = (RelativeLayout) findViewById(R.id.show_image_layout);

        SharedPreferences myPref = getApplicationContext().getSharedPreferences("MyPreferences", MODE_PRIVATE);


        //set the background color based on preferences
        String bckgrndColor = myPref.getString("color", null);
        switch(bckgrndColor){
            case "b":
                layout.setBackgroundColor(getResources().getColor(R.color.blue));
                break;
            case "p":
                layout.setBackgroundColor(getResources().getColor(R.color.purple));
                break;
            case "g":
                layout.setBackgroundColor(getResources().getColor(R.color.green));
                break;
            case "o":
                layout.setBackgroundColor(getResources().getColor(R.color.orange));
                break;
            case "y":
                layout.setBackgroundColor(getResources().getColor(R.color.yellow));
                break;
            case "r":
                layout.setBackgroundColor(getResources().getColor(R.color.red));
                break;
            case "pi":
                layout.setBackgroundColor(getResources().getColor(R.color.pink));
                break;
            default:
                break;
        }

        if(!imgSrc.equals("")) {
            int imgID1 = getResources().getIdentifier(imgSrc, "drawable", getPackageName());
            int imgID2  = getResources().getIdentifier(imgSrc, "drawable", getPackageName());

            img.setImageResource(imgID1);

        }

    }

    public void doneShowImage(View v){
        finish();
    }
}
