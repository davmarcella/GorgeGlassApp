package com.example.david.mapapp;

/**
 * Created by David on 11/29/16.
 */

public class LostItem {

    private int id;
    private String itemLost;
    private String clues;
    private String latitude;
    private String longitude;
    private int found;
    private String imgText1;
    private String imgText2;

    public LostItem(){
    }

    public LostItem(int id, String itemLost, String clues, String latitude, String longitude, int found, String img1, String img2){
        this.id = id;
        this.itemLost = itemLost;
        this.clues = clues;
        this.latitude = latitude;
        this.longitude = longitude;
        this.found = found;
        this.imgText1 = img1;
        this.imgText2 = img2;
    }


    public void setId(int i){id = i;}

    public void setItem(String item){itemLost = item;}

    public void setClues(String nClues){clues = nClues;}

    public void setLat(String l){latitude = l;}

    public void setLong(String l){longitude = l;}

    public void setFound(int f){found = f;}

    public void setImgText1(String str){imgText1 = str;}

    public void setImgText2(String str){imgText2 = str;}

    public int getId(){return id;}

    public String getItem(){return itemLost;}

    public String getClues(){return clues;}

    public String getLat(){return latitude;}

    public String getLong(){return longitude;}

    public int found(){return found;}

    public String getImgText1(){return imgText1;}

    public String getImgText2(){return imgText2;}

}
